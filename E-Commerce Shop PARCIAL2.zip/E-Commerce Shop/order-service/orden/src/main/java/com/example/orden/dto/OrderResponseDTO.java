package com.example.orden.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class OrderResponseDTO {
    private Long id;

    private Long clientId;

    private Long cartId;

    private Double total;

    private String status;

    private LocalDateTime createdAt;
}
