package com.example.orden.controller;

import com.example.orden.dto.OrderResponseDTO;
import com.example.orden.service.OrdenService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/orders")
public class OrdenController {

    private final OrdenService service;

    public OrdenController(OrdenService service) {

        this.service = service;
    }

    // =========================================
    // CREATE ORDER
    // =========================================

    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @PostMapping
    public ResponseEntity<OrderResponseDTO> createOrder() {

        OrderResponseDTO response = service.createOrder();

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(response);
    }

    // =========================================
    // GET MY ORDERS
    // =========================================

    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @GetMapping("/me")
    public ResponseEntity<List<OrderResponseDTO>>getMyOrders() {
        return ResponseEntity.ok(
                service.getMyOrders()
        );

    }

    // =========================================
    // GET ORDER BY ID
    // =========================================

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/{id}")
    public ResponseEntity<OrderResponseDTO> getById(@PathVariable Long id) {
        return ResponseEntity.ok(service.getById(id)
        );
    }

    // =========================================
    // GET ALL ORDERS
    // =========================================

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping
    public ResponseEntity<List<OrderResponseDTO>> getAll() {

        return ResponseEntity.ok(service.getAll()
        );
    }

    // =========================================
    // UPDATE STATUS
    // =========================================

    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/{id}/status")
    public ResponseEntity<OrderResponseDTO>
    updateStatus(@PathVariable Long id, @RequestParam String status) {

        return ResponseEntity.ok(service.updateStatus(id, status));
    }

    // =========================================
    // CANCEL MY ORDER
    // =========================================

    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @PutMapping("/{id}/cancel")
    public ResponseEntity<OrderResponseDTO> cancelMyOrder(@PathVariable Long id) {

        return ResponseEntity.ok(service.cancelMyOrder(id));
    }

    // =========================================
    // DELETE ORDER
    // =========================================

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteOrder(@PathVariable Long id) {

        service.deleteOrder(id);

        return ResponseEntity
                .noContent()
                .build();
    }

}