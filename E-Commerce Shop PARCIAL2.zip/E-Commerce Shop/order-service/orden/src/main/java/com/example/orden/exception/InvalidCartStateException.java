package com.example.orden.exception;

public class InvalidCartStateException extends RuntimeException {

    public InvalidCartStateException(String message) {

        super(message);
    }
}
