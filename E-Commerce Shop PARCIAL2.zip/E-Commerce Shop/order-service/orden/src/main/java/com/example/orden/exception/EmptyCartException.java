package com.example.orden.exception;

public class EmptyCartException extends RuntimeException {

    public EmptyCartException(String message) {

        super(message);
    }
}