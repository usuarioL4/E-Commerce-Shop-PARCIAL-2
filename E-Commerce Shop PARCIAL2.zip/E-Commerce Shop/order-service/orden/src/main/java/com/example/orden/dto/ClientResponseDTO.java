package com.example.orden.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ClientResponseDTO {

    private Long id;

    private Long userId;

    private String nombre;

    private String correo;

    private String telefono;

    private String direccion;

    private String rut;
}