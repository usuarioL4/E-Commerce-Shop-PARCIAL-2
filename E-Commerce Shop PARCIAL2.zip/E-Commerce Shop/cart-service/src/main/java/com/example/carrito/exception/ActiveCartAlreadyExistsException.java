package com.example.carrito.exception;

public class ActiveCartAlreadyExistsException extends RuntimeException {

    public ActiveCartAlreadyExistsException(String message) {

        super(message);
    }
}