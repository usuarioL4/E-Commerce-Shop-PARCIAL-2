package com.example.carrito.exception;

public class InsufficientStockException extends RuntimeException {

    public InsufficientStockException(String message) {

        super(message);
    }
}

