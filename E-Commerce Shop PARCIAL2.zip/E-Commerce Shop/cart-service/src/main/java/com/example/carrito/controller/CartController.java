package com.example.carrito.controller;

import com.example.carrito.dto.CartRequestDTO;
import com.example.carrito.dto.CartResponseDTO;
import com.example.carrito.service.CartService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/cart")
public class CartController {

    private final CartService service;

    public CartController(CartService service) {
        this.service = service;
    }

    // =========================================
    // CREATE CART
    // =========================================

    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @PostMapping
    public ResponseEntity<CartResponseDTO> createCart() {

        return ResponseEntity.status(HttpStatus.CREATED).body(service.createCart());
    }

    // =========================================
    // GET MY CART
    // =========================================

    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @GetMapping("/me")
    public ResponseEntity<CartResponseDTO> getMyCart() {

        return ResponseEntity.ok(service.getMyCart());
    }

    // =========================================
    // CANCEL MY CART
    // =========================================

    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @DeleteMapping("/me")
    public ResponseEntity<Void> cancelMyCart() {

        service.cancelMyCart();
        return ResponseEntity.noContent().build();
    }

    // =========================================
    // GET MY TOTAL
    // =========================================

    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @GetMapping("/total-price")
    public ResponseEntity<Double> getMyTotal() {

        return ResponseEntity.ok(service.getMyTotal());
    }

    // =========================================
    // ADMIN METHODS
    // =========================================

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping
    public ResponseEntity<List<CartResponseDTO>> getAllCarts() {

        return ResponseEntity.ok(service.getAllCarts());
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/{id}")
    public ResponseEntity<CartResponseDTO> getCartById(@PathVariable Long id) {

        return ResponseEntity.ok(service.getCartById(id));
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/{id}")
    public ResponseEntity<CartResponseDTO> updateCart(@PathVariable Long id, @Valid @RequestBody CartRequestDTO request) {

        return ResponseEntity.ok(service.updateCart(id, request));
    }

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void>
    deleteCart(@PathVariable Long id) {
        service.deleteCart(id);

        return ResponseEntity.noContent().build();}
}