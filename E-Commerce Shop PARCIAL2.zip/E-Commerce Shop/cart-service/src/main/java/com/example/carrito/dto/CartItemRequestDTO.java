package com.example.carrito.dto;

import lombok.Data;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

@Data
public class CartItemRequestDTO {

    @NotNull(message = "ProductId is required")
    private Long productId;

    @NotNull(message = "Cantidad is required")
    @Min(value = 1, message = "Cantidad must be greater than 0")
    private Integer stock;
}