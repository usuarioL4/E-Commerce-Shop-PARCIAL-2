package com.example.carrito.controller;

import com.example.carrito.dto.CartItemRequestDTO;
import com.example.carrito.dto.CartItemResponseDTO;
import com.example.carrito.service.CartItemService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/cart/items")
public class CartItemController {

    private final CartItemService service;

    public CartItemController(CartItemService service) {
        this.service = service;
    }

    // =========================================
    // CREATE ITEM
    // =========================================

    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @PostMapping
    public ResponseEntity<CartItemResponseDTO> createItem(@Valid @RequestBody CartItemRequestDTO request) {

        return ResponseEntity.status(HttpStatus
                .CREATED).body(service.createItem(request));
    }

    // =========================================
    // GET MY ITEMS
    // =========================================

    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @GetMapping("/me")
    public ResponseEntity<List<CartItemResponseDTO>> getMyItems() {
        return ResponseEntity.ok(service.getMyItems());
    }

    // =========================================
    // UPDATE ITEM
    // =========================================

    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @PutMapping("/{id}")
    public ResponseEntity<CartItemResponseDTO>
    updateItem(@PathVariable Long id, @Valid @RequestBody CartItemRequestDTO request) {

        return ResponseEntity.ok(service.updateItem(id, request));
    }

    // =========================================
    // DELETE ITEM
    // =========================================

    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void>
    deleteItem(@PathVariable Long id) {

        service.deleteItem(id);

        return ResponseEntity.noContent().build();
    }

    // =========================================
    // ADMIN - ITEMS BY CART
    // =========================================

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/cart/{cartId}")
    public ResponseEntity<List<CartItemResponseDTO>>
    getItemsByCart(@PathVariable Long cartId) {

        return ResponseEntity.ok(service.getItemsByCart(cartId));
    }
}