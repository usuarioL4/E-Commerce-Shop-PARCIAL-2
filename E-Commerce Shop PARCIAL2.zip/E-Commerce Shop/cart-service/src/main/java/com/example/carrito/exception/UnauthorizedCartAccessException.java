package com.example.carrito.exception;

public class UnauthorizedCartAccessException extends RuntimeException{
    public UnauthorizedCartAccessException(String message) {

        super(message);
    }
}
