package com.example.carrito.exception;

public class InvalidCartStateException extends RuntimeException{
    public InvalidCartStateException(String message) {

        super(message);
    }
}
