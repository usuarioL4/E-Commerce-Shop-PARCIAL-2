package com.example.carrito.dto;

import lombok.Data;

@Data
public class ClientResponseDTO {

    private Long id;
    private Long userId;
    private String name;
}