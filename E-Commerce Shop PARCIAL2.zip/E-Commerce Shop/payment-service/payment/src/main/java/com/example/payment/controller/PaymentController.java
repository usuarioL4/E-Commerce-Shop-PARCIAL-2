package com.example.payment.controller;

import com.example.payment.dto.PaymentRequestDTO;
import com.example.payment.dto.PaymentResponseDTO;
import com.example.payment.service.PaymentService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/payments")
public class PaymentController {

    private final PaymentService service;
    public PaymentController(PaymentService service) {
        this.service = service;
    }

    // =========================================
    // CREATE PAYMENT
    // =========================================

    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @PostMapping

    public ResponseEntity<PaymentResponseDTO> create(@Valid @RequestBody PaymentRequestDTO request) {

        PaymentResponseDTO response = service.create(request);

        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }
}