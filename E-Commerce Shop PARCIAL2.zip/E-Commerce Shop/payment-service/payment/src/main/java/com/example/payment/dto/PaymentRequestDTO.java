package com.example.payment.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class PaymentRequestDTO {
    //se agrega orden manual, ya que puede contar con una orden o mas +  agrega un metodo de pago manual ya que un cliente puede tener uno o varios metodos de pago
    @NotNull
    private Long orderId;
    @NotNull
    private Long paymentMethodId;
}
