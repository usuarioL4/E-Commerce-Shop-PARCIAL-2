package com.example.catalogos.controller;

import com.example.catalogos.dto.CategoryRequestDTO;
import com.example.catalogos.dto.CategoryResponseDTO;
import com.example.catalogos.dto.ProductResponseDTO;
import com.example.catalogos.service.CatalogoService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/categories")
public class CatalogoController {

    private final CatalogoService service;

    public CatalogoController(CatalogoService service) {
        this.service = service;
    }

    // CREATE CATEGORY

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping
    public ResponseEntity<CategoryResponseDTO>
    create(@Valid @RequestBody CategoryRequestDTO request) {

        CategoryResponseDTO response = service.create(request);

        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    // GET CATEGORY BY ID

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/{id}")
    public ResponseEntity<CategoryResponseDTO> getById(@PathVariable Long id) {

        return ResponseEntity.ok(service.getById(id));
    }

    // GET ALL CATEGORIES

    @GetMapping
    public ResponseEntity<List<CategoryResponseDTO>> getAll() {

        return ResponseEntity.ok(service.getAll());
    }

    // UPDATE CATEGORY

    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/{id}")
    public ResponseEntity<CategoryResponseDTO> update(@PathVariable Long id, @Valid @RequestBody CategoryRequestDTO request) {

        return ResponseEntity.ok(service.update(id, request));
    }

    // DELETE CATEGORY

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, String>> delete(@PathVariable Long id) {
        service.delete(id);

        return ResponseEntity.ok(
                Map.of("message", "Category deleted successfully"));
    }

    // GET PRODUCTS BY CATEGORY
    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @GetMapping("/{id}/products")
    public ResponseEntity<List<ProductResponseDTO>> getProducts(@PathVariable Long id) {

        return ResponseEntity.ok(service.getProductsByCategory(id));
    }
}