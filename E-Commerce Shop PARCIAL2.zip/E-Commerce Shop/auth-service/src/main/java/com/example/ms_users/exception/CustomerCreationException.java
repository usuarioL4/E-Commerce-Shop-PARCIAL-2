package com.example.ms_users.exception;

public class CustomerCreationException extends RuntimeException {

    public CustomerCreationException(String message) {

        super(message);
    }
}
