package com.example.ms_users.dto;

import lombok.Data;
//no se valida en customer porque ya se valido en el fullrequestDTO
@Data
public class CustomerRequestDTO {
    //es el json que se enviara al otro microservicio
    private String name;
    private String rut;
    private String email;
    private String address;
    private String phone;


    private Long userId;
}
