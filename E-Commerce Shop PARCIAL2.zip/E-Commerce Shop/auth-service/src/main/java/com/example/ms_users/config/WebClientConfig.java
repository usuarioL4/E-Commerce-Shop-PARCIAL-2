package com.example.ms_users.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class WebClientConfig {
    @Bean //el cliente cual interactuara con el otro microservicio
    public WebClient webClient(){
        return WebClient.builder()
                .baseUrl("http://localhost:8083/api/v1/customer")
                .build();
    }
}
