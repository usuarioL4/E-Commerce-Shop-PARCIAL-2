package com.example.productos.controller;

import com.example.productos.dto.ProductFullRequestDTO;
import com.example.productos.dto.ProductRequestDTO;
import com.example.productos.dto.ProductResponseDTO;
import com.example.productos.service.ProductService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/products")
public class ProductController {

    private final ProductService service;

    public ProductController(ProductService service) {

        this.service = service;
    }

    // CREATE

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping
    public ResponseEntity<ProductResponseDTO>
    create(@Valid @RequestBody ProductFullRequestDTO request) {

        ProductResponseDTO response = service.createFullProduct(request);

        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    // GET BY ID

    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @GetMapping("/{id}")
    public ResponseEntity<ProductResponseDTO> getById(@PathVariable Long id) {

        return ResponseEntity.ok(service.getById(id));
    }

    // GET ALL

    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @GetMapping
    public ResponseEntity<List<ProductResponseDTO>> getAll() {

        return ResponseEntity.ok(service.getAll());
    }

    // UPDATE

    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/{id}")
    public ResponseEntity<ProductResponseDTO> update(@PathVariable Long id, @Valid @RequestBody ProductRequestDTO request) {

        return ResponseEntity.ok(service.update(id, request));
    }

    // DELETE

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, String>> delete(@PathVariable Long id) {

        service.delete(id);
        return ResponseEntity.ok(Map.of("message", "Product deleted successfully"));
    }

    // GET BY CATEGORY
    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @GetMapping("/category/{categoryId}")
    public ResponseEntity<List<ProductResponseDTO>>
    getByCategory(@PathVariable Long categoryId) {

        return ResponseEntity.ok(service.getByCategory(categoryId));
    }
}