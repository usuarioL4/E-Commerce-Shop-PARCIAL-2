package com.example.productos.dto;

import jakarta.validation.constraints.*;
import lombok.Data;
@Data
public class ProductFullRequestDTO {
    @Size(min = 3, max = 50, message = "Name must be between 3 and 30 characters")
    @NotBlank(message = "Name is required")
    private String name;

    @Size(min = 4, max = 400, message = "Description must be between 4 and 80 characters")
    @NotBlank(message = "Description is required")
    private String description;

    @NotNull(message = "Price is required")
    @Positive(message = "Price must be greater than 0")
    private Double price;

    @NotNull(message = "CategoryId is required")
    private Long categoryId;

    @NotNull(message = "Stock is required")
    @Min(value = 1, message = "Stock must be greater than 0")
    private Integer stock;
}