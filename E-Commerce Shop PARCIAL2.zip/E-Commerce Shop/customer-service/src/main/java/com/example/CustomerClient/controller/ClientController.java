package com.example.CustomerClient.controller;

import com.example.CustomerClient.dto.ClientRequestDTO;
import com.example.CustomerClient.dto.ClienteResponseDTO;
import com.example.CustomerClient.model.Client;
import com.example.CustomerClient.service.ClientService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/customer")
public class ClientController {

    private final ClientService service;

    public ClientController(ClientService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<Client> create(@Valid @RequestBody ClientRequestDTO request) {

        Client client = service.create(request);

        return ResponseEntity.status(HttpStatus.CREATED).body(client);
    }

    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<Client>> findAll() {

        return ResponseEntity.ok(service.findAll());
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Client> findById(@PathVariable Long id) {

        return ResponseEntity.ok(service.findById(id));
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<ClienteResponseDTO> getByUserId(@PathVariable Long userId) {

        return ResponseEntity.ok(service.getByUserId(userId));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Client> updateClient(@Valid @RequestBody ClientRequestDTO request, @PathVariable Long id) {

        return ResponseEntity.ok(service.update(request, id));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Map<String, String>> deleteById(@PathVariable Long id) {

        service.delete(id);
        return ResponseEntity.ok(Map.of("message", "Client deleted successfully"));
    }
}